using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

using UnityEngine;
using UnityEngine.Rendering;

using static Trees.TreeEditor;

namespace Trees
{
    internal static class Extensions
    {
        public static bool IsFlipped(this Transform transform)
        {
            return transform.lossyScale.x < 0f;
        }

        ///	<summary>
        ///	Sets the size of the <paramref name="transform"/>.
        ///	</summary>
        ///	<seealso cref="SetSize(Transform, float, out bool)"/>
        ///	<param name="transform"><see cref="Transform"/> that is sized.</param>
        ///	<param name="size">Size to be set (reflected by x if the <paramref name="transform"/> is flipped).</param>
        public static void SetSize(this Transform transform, float size)
        {
            SetSize(transform, size, out _);
        }
        public static Transform[] GetChilds(this Transform transform)
        {
            List<Transform> values = new List<Transform>();
            for (var i = 0; i < transform.childCount; i++)
            {
                values.Add(transform.GetChild(i));
            }
            return values.ToArray();
        }
        ///	<seealso cref="SetSize(Transform, float)"/>
        ///	<inheritdoc cref="SetSize(Transform, float))"/>
        ///	<param name="flipped">If the object is upside down (x < 0) true, otherwise false.</param>
        public static void SetSize(this Transform transform, float size, out bool flipped)
        {
            flipped = transform.IsFlipped();
            transform.localScale = new Vector3(size * (flipped ? -1f : 1f), size, 0f);
        }

        /// <summary>
        /// Destroys all components of type <see cref="Collider2D"/> in <paramref name="gameObject"/>.
        /// </summary>
        public static void DestroyAllColliders(this GameObject gameObject)
        {
            foreach (Collider2D collider in gameObject.GetComponents<Collider2D>())
            {
                Collider2D.Destroy(collider);
            }
        }

        /// <summary>
        /// Play a <paramref name="clip"/> at a <paramref name="position"/> in world space.
        /// </summary>
        /// <param name="clip"><see cref="AudioClip"/> to be played.</param>
        /// <param name="position">The <paramref name="clip"/>'s playback point in world space.</param>
        public static void PlayAtPoint(this AudioClip clip, Vector3 position)
        {
            GameObject gameObject = new GameObject("One shot audio");
            gameObject.layer = 10;
            gameObject.transform.position = position;
            AudioSource audioSource = gameObject.AddComponent<AudioSource>();
            audioSource.clip = clip;
            gameObject.AddComponent<AudioSourceTimeScaleBehaviour>();
            gameObject.AddComponent<Optout>();
            audioSource.Play();

            UnityEngine.Object.Destroy(gameObject, clip.length * ((Time.timeScale < 0.01f) ? 0.01f : Time.timeScale));
        }

        /// <summary>
        /// Recreates the array <see cref="SerialiseInstructions.RelevantTransforms"/> of this <paramref name="gameObject"/>.
        /// </summary>
        public static void UpdateSerialiseInstructions(this GameObject gameObject)
        {
            SerialiseInstructions serialiseInstructions = gameObject.GetComponent<SerialiseInstructions>();
            serialiseInstructions.StartCoroutine(UpdateSerialiseInstructionsRoutine(serialiseInstructions));
        }
        /// <summary>
        /// Recreates the array <see cref="SerialiseInstructions.RelevantTransforms"/>.
        /// </summary>
        public static void UpdateSerialiseInstructions(this SerialiseInstructions serialiseInstructions)
        {
            serialiseInstructions.StartCoroutine(UpdateSerialiseInstructionsRoutine(serialiseInstructions));
        }
        private static IEnumerator UpdateSerialiseInstructionsRoutine(SerialiseInstructions serialiseInstructions)
        {
            yield return null;
            typeof(SerialiseInstructions).GetMethod("Start", BindingFlags.Instance | BindingFlags.NonPublic).Invoke(serialiseInstructions, new object[0]);
        }

        public static void SetSorting(this SpriteRenderer spriteRenderer, in SpriteRenderer otherSpriteRenderer, in int offset)
        {
            spriteRenderer.sortingLayerName = otherSpriteRenderer.sortingLayerName;
            spriteRenderer.sortingOrder = otherSpriteRenderer.sortingOrder + offset;
        }
        public static void SetSorting(this SortingGroup sortingGroup, in SpriteRenderer otherSpriteRenderer, in int offset)
        {
            sortingGroup.sortingLayerName = otherSpriteRenderer.sortingLayerName;
            sortingGroup.sortingOrder = otherSpriteRenderer.sortingOrder + offset;
        }
    }
    public static class TreeEditor
    {
        public readonly struct JointData
        {
            public readonly bool CustomData;
            public readonly float BreakForce;
            public readonly float DampingRatio;
            public readonly float Frequency;

            public JointData(float breakForce)
            {
                CustomData = true;
                BreakForce = breakForce;
                DampingRatio = -1f;
                Frequency = -1f;
            }
            public JointData(float breakForce, float dampingRatio, float frequency)
            {
                CustomData = true;
                BreakForce = breakForce;
                DampingRatio = dampingRatio;
                Frequency = frequency;
            }

            public void ApplyTo(FixedJoint2D newJoint)
            {
                if (CustomData)
                {
                    newJoint.breakForce = BreakForce;
                    if (DampingRatio != -1f)
                    {
                        newJoint.dampingRatio = DampingRatio;
                        newJoint.frequency = Frequency;
                    }
                }
            }
            public void ApplyTo(FixedJoint2D oldJoint, FixedJoint2D newJoint)
            {
                if (CustomData)
                {
                    newJoint.breakForce = BreakForce;
                    if (DampingRatio != -1f)
                    {
                        newJoint.dampingRatio = DampingRatio;
                        newJoint.frequency = Frequency;
                    }
                    else
                    {
                        newJoint.dampingRatio = oldJoint.dampingRatio;
                        newJoint.frequency = oldJoint.frequency;
                    }
                }
                else
                {
                    newJoint.breakForce = oldJoint.breakForce;
                    newJoint.dampingRatio = oldJoint.dampingRatio;
                    newJoint.frequency = oldJoint.frequency;
                }
            }
        }

        public static readonly SpawnableAsset TallTreeAsset = ModAPI.FindSpawnable("Tall Tree");

        private static readonly FieldInfo MaterialPropertyField = typeof(FoliageBehaviour).GetField("materialProperty", BindingFlags.NonPublic | BindingFlags.Instance);

        #region Trunk
        public static GameObject SetTrunkSprite(this GameObject treeRoot, Sprite sprite, Vector2[] polygonPoints)
        {
            GameObject trunk = treeRoot.transform.GetChild(0).gameObject;

            PhysicalBehaviour trunkPhys = trunk.GetComponent<PhysicalBehaviour>();
            trunkPhys.spriteRenderer.sprite = sprite;
            trunk.FixColliders();
            trunkPhys.StartCoroutine(SetPolygonPointsRoutine(trunkPhys, polygonPoints));

            if (!treeRoot.GetComponent<ObjectSerialisationHelper>())
            {
                treeRoot.AddComponent<ObjectSerialisationHelper>();
                trunk.transform.localPosition = new Vector3(0f, sprite.rect.height * ModAPI.PixelSize / 2f);
            }

            Component.Destroy(trunk.GetComponent<RandomSpriteBehaviour>());

            return trunk;
        }
        private static IEnumerator SetPolygonPointsRoutine(PhysicalBehaviour objPhys, Vector2[] points)
        {
            yield return null;
            objPhys.ResetColliderArray();
            objPhys.GetComponent<LocalFirePropagationMap>().Collider = objPhys.colliders[0];
            PolygonCollider2D polygonCollider = (PolygonCollider2D)objPhys.colliders[0];
            polygonCollider.pathCount = 1;
            polygonCollider.SetPath(0, points);
        }
        #endregion

        #region Leaves
        public static void SetLeafSprite(this FoliageBehaviour leaf, Sprite sprite)
        {
            MaterialPropertyBlock materialPropertyBlock = new MaterialPropertyBlock();
            leaf.Renderer.GetPropertyBlock(materialPropertyBlock);

            Color oldColor = ((MaterialPropertyBlock)MaterialPropertyField.GetValue(leaf)).GetColor("_LeafTint");
            materialPropertyBlock.SetColor("_LeafTint", oldColor);
            MaterialPropertyField.SetValue(leaf, materialPropertyBlock);
        }
        public static void SetLeafSprite(this FoliageBehaviour leaf, Sprite sprite, Color color)
        {
            MaterialPropertyBlock materialPropertyBlock = new MaterialPropertyBlock();
            leaf.Renderer.GetPropertyBlock(materialPropertyBlock);
            materialPropertyBlock.SetColor("_LeafTint", color);
            MaterialPropertyField.SetValue(leaf, materialPropertyBlock);
        }

        public static void AddLeaf(this GameObject treeRoot, int branchIndex, Vector2 localPosition, Sprite sprite, Color color)
        {
            Transform branch = treeRoot.transform.GetChild(branchIndex);
            GameObject leafObj = GameObject.Instantiate<GameObject>(TallTreeAsset.Prefab.transform.GetChild(0).GetChild(0).gameObject, branch);

            leafObj.transform.localPosition = localPosition;
            SpringJoint2D leafJoint = leafObj.GetComponent<SpringJoint2D>();
            leafJoint.connectedBody = branch.GetComponent<Rigidbody2D>();
            leafJoint.connectedAnchor = leafJoint.connectedBody.transform.InverseTransformPoint(leafObj.transform.position);

            leafObj.GetComponent<FoliageBehaviour>().SetLeafSprite(sprite, color);
        }

        public static void SetLeavesSprites(this GameObject treeRoot, (Sprite, Color)[] leavesData, Sprite[] leafParticleSprites)
        {
            int leafParticleSpritesLength = leafParticleSprites.Length;

            FoliageBehaviour[] leaves = treeRoot.GetComponentsInChildren<FoliageBehaviour>();
            for (int i = 0; i < leaves.Length; i++)
            {
                FoliageBehaviour leaf = leaves[i];
                (Sprite, Color) leafData = leavesData.PickRandom();
                leaf.SetLeafSprite(leafData.Item1, leafData.Item2);

                if (leaf.TryGetComponent<ParticleSystem>(out ParticleSystem particleSystem))
                {
                    ParticleSystemRenderer particleSystemRenderer = leaf.GetComponent<ParticleSystemRenderer>();

                    MaterialPropertyBlock materialPropertyBlock = new MaterialPropertyBlock();
                    particleSystemRenderer.GetPropertyBlock(materialPropertyBlock);
                    materialPropertyBlock.SetColor("_LeafTint", leafData.Item2);
                    particleSystemRenderer.SetPropertyBlock(materialPropertyBlock);

                    particleSystem.textureSheetAnimation.RemoveSprite(0);
                    for (int i2 = 0; i2 < leafParticleSpritesLength; i2++)
                    {
                        particleSystem.textureSheetAnimation.AddSprite(leafParticleSprites[i2]);
                    }
                }
            }
        }

        public static void EditLeaves(this GameObject treeRoot, int branchIndex, Vector2[] leavesPositions)
        {
            FoliageBehaviour leaf;
            FoliageBehaviour[] leaves = treeRoot.transform.GetChild(branchIndex).GetComponentsInChildren<FoliageBehaviour>();

            int minLength = Mathf.Min(leavesPositions.Length, leaves.Length);
            for (int i = 0; i < minLength; i++)
            {
                leaf = leaves[i];
                if (leavesPositions[i] == Vector2.zero)
                {
                    GameObject.Destroy(leaf.gameObject);
                }
                leaf.transform.localPosition = leavesPositions[i];
                SpringJoint2D leafJoint = leaf.GetComponent<SpringJoint2D>();
                leafJoint.connectedAnchor = leafJoint.connectedBody.transform.InverseTransformPoint(leaf.transform.position);
            }
        }
        public static void EditLeaves(this GameObject treeRoot, int branchIndex, (Vector2, Sprite)[] leavesData)
        {
            FoliageBehaviour leaf;
            FoliageBehaviour[] leaves = treeRoot.transform.GetChild(branchIndex).GetComponentsInChildren<FoliageBehaviour>();

            int minLength = Mathf.Min(leavesData.Length, leaves.Length);
            for (int i = 0; i < minLength; i++)
            {
                leaf = leaves[i];
                (Vector2 pos, Sprite sprite) = leavesData[i];
                if (sprite == null)
                {
                    GameObject.Destroy(leaf.gameObject);
                }

                leaf.transform.localPosition = pos;
                SpringJoint2D leafJoint = leaf.GetComponent<SpringJoint2D>();
                leafJoint.connectedAnchor = leafJoint.connectedBody.transform.InverseTransformPoint(leaf.transform.position);

                leaf.SetLeafSprite(sprite);
            }
        }
        public static void EditLeaves(this GameObject treeRoot, int branchIndex, (Vector2, Sprite, Color)[] leavesData)
        {
            FoliageBehaviour leaf;
            FoliageBehaviour[] leaves = treeRoot.transform.GetChild(branchIndex).GetComponentsInChildren<FoliageBehaviour>();

            int minLength = Mathf.Min(leavesData.Length, leaves.Length);
            for (int i = 0; i < minLength; i++)
            {
                leaf = leaves[i];
                (Vector2 pos, Sprite sprite, Color color) = leavesData[i];

                if (sprite == null)
                {
                    GameObject.Destroy(leaf.gameObject);
                }

                leaf.transform.localPosition = pos;
                SpringJoint2D leafJoint = leaf.GetComponent<SpringJoint2D>();
                leafJoint.connectedAnchor = leafJoint.connectedBody.transform.InverseTransformPoint(leaf.transform.position);

                leaf.SetLeafSprite(sprite, color);
            }
        }

        public static void DestroyLeaf(this GameObject treeRoot, int branchIndex, int leafIndex)
        {
            GameObject.Destroy(treeRoot.transform.GetChild(branchIndex).GetChild(leafIndex).gameObject);
        }
        public static void DestroyAllLeaves(this GameObject treeRoot, int branchIndex)
        {
            Transform branch = treeRoot.transform.GetChild(branchIndex);
            foreach (Transform child in branch)
            {
                GameObject.Destroy(child.gameObject);
            }
        }
        #endregion

        #region Branch
        public static GameObject AddBranch(this GameObject treeRoot, Sprite sprite, Vector2 localPosition, float localRotation, JointData jointData = default)
        {
            GameObject branchObj = GameObject.Instantiate<GameObject>(TallTreeAsset.Prefab.transform.GetChild(1).gameObject, treeRoot.transform);
            EditBranch(treeRoot, branchObj.transform, sprite, localPosition, localRotation, jointData);
            return branchObj;
        }
        public static GameObject AddBranch(this GameObject treeRoot, int branchIndexForAttach, Sprite sprite, Vector2 localPosition, float localRotation, JointData jointData = default)
        {
            GameObject branchObj = GameObject.Instantiate<GameObject>(TallTreeAsset.Prefab.transform.GetChild(1).gameObject, treeRoot.transform);
            EditBranch(treeRoot, branchObj.transform, sprite, localPosition, localRotation, jointData, branchIndexForAttach);
            return branchObj;
        }

        public static void DestroyBranch(this GameObject treeRoot, int branchIndex)
        {
            GameObject.Destroy(treeRoot.transform.GetChild(branchIndex).gameObject);
        }

        public static GameObject EditBranch(this GameObject treeRoot, int branchIndex, Sprite sprite, Vector2 localPosition, float localRotation, JointData jointData = default)
        {
            Transform branch = treeRoot.transform.GetChild(branchIndex);
            EditBranch(treeRoot, branch, sprite, localPosition, localRotation, jointData);
            return branch.gameObject;
        }
        public static GameObject EditBranch(this GameObject treeRoot, int branchIndex, int branchIndexForAttach, Sprite sprite, Vector2 localPosition, float localRotation, JointData jointData = default)
        {
            Transform branch = treeRoot.transform.GetChild(branchIndex);
            EditBranch(treeRoot, branch, sprite, localPosition, localRotation, jointData, branchIndexForAttach);
            return branch.gameObject;
        }

        private static void EditBranch(GameObject treeRoot, Transform branch, Sprite sprite, Vector2 localPosition, float localRotation, JointData jointData = default, int branchIndexForAttach = -1)
        {
            GameObject branchObj = branch.gameObject;
            branchObj.name = $"Branch ({branch.GetSiblingIndex()})";

            PhysicalBehaviour branchPhys = branchObj.GetComponent<PhysicalBehaviour>();
            branchPhys.spriteRenderer.sprite = sprite;
            branchObj.FixColliders();

            if (branchPhys.SortingGroup == null)
            {
                branchPhys.SortingGroup = branchObj.AddComponent<SortingGroup>();
            }

            branchPhys.StartCoroutine(ResetColliderArrayRoutine(branchPhys)); //* without this, there will be a destroyed collider in the array with colliders (I don't know why)

            branch.localPosition = localPosition;
            branch.eulerAngles = new Vector3(0f, 0f, treeRoot.transform.GetChild(0).eulerAngles.z + (treeRoot.transform.IsFlipped() ? -localRotation : localRotation));

            FixedJoint2D oldJoint = branchObj.GetComponent<FixedJoint2D>();
            FixedJoint2D joint = branchObj.AddComponent<FixedJoint2D>();
            jointData.ApplyTo(oldJoint, joint);

            Rigidbody2D connectedBody;
            if (branchIndexForAttach == -1)
            {
                connectedBody = oldJoint.connectedBody;
            }
            else
            {
                connectedBody = branch.parent.GetChild(branchIndexForAttach).GetComponent<Rigidbody2D>();
            }
            joint.connectedBody = connectedBody;

            joint.anchor = new Vector2(branchPhys.spriteRenderer.sprite.rect.width * ModAPI.PixelSize / -2f, 0f);
            joint.connectedAnchor = connectedBody.transform.InverseTransformPoint(branch.TransformPoint(joint.anchor));

            branchObj.GetComponent<JointSerialisationHelper>().Joint = joint;

            FixedJoint2D.Destroy(oldJoint);

            branchObj.AddComponent<Optout>();
            treeRoot.GetComponent<ObjectSerialisationHelper>().Objects.Add(branchObj);
        }
        #endregion

        public static GameObject AddObject(this GameObject treeRoot, int branchIndex, Sprite sprite, Vector2 localPosition, float localRotation, Vector2 anchor, JointData jointData = default, string properties = "Soft")
        {
            Transform branch = treeRoot.transform.GetChild(branchIndex);
            PhysicalBehaviour branchPhys = branch.GetComponent<PhysicalBehaviour>();

            GameObject obj = ModAPI.CreatePhysicalObject("", sprite);

            Transform objTransform = obj.transform;
            objTransform.SetParent(branch);
            objTransform.localPosition = localPosition; //treeRoot.transform.InverseTransformPoint(branch.TransformPoint(localPosition));
            objTransform.eulerAngles = new Vector3(0f, 0f, branch.eulerAngles.z + (treeRoot.transform.IsFlipped() ? -localRotation : localRotation));

            obj.name = $"Object ({obj.transform.GetSiblingIndex()})";

            FixedJoint2D joint = obj.AddComponent<FixedJoint2D>();
            joint.connectedBody = branchPhys.rigidbody;
            jointData.ApplyTo(joint);
            joint.anchor = anchor;
            joint.connectedAnchor = branchPhys.transform.InverseTransformPoint(objTransform.TransformPoint(anchor));

            PhysicalBehaviour objPhys = obj.GetComponent<PhysicalBehaviour>();
            objPhys.Properties = ModAPI.FindPhysicalProperties(properties);
            objPhys.spriteRenderer.sortingLayerName = "Background";
            objPhys.spriteRenderer.sortingOrder = 0;

            JointSerialisationHelper jointSerialisationHelper = obj.AddComponent<JointSerialisationHelper>();
            jointSerialisationHelper.Joint = joint;
            obj.AddComponent<ChangeParentOnJointBreak>().Set(jointSerialisationHelper, treeRoot.transform);

            obj.AddComponent<Optout>();
            treeRoot.GetComponent<ObjectSerialisationHelper>().Objects.Add(obj);

            return obj;
        }

        private static IEnumerator ResetColliderArrayRoutine(PhysicalBehaviour phys)
        {
            yield return null;
            phys.ResetColliderArray();
            if (phys.TryGetComponent<LocalFirePropagationMap>(out LocalFirePropagationMap fireMap))
            {
                fireMap.Collider = phys.colliders[0];
            }
        }
    }
    public class Mod
    {
        public static bool NewUpdateWindowHasBeenOpened = false;
        public const string LastViewedVersionJsonPath = "More Nature Mod_LastViewedVersion.json";

        public static void OpenLink(string url)
        {
            typeof(Utils).GetMethod("OpenURL", BindingFlags.Public | BindingFlags.Static).Invoke(null, new object[1] { url });
        }
        public static void TryCreateInfoWindow()
        {
            if (NewUpdateWindowHasBeenOpened)
            {
                return;
            }

            string lastVersion = "";
            try
            {
                lastVersion = ModAPI.DeserialiseJSON<string>(LastViewedVersionJsonPath);
            }
            catch
            {
            }

            string thisVersion = ModLoader.LoadedMods.Find((ModMetaData meta) => meta.Name == "More Nature" && meta.Author == "Int team").ModVersion;
            NewUpdateWindowHasBeenOpened = thisVersion == lastVersion;

            if (!NewUpdateWindowHasBeenOpened)
            {
                if (!NewUpdateWindowHasBeenOpened)
                {
                    DialogBox discordInvite = DialogBoxManager.Dialog("If you haven't seen the trailer, please watch it! Also on this channel you will see trailers and new information about other mods", new DialogButton[]
                    {
                        new DialogButton("Trailer", false, () =>
                        {
                            OpenLink("https://www.youtube.com/watch?v=BYNSnQKc3cE&ab_channel=IntTeam");
                        }),
                        new DialogButton("Discord", false, () =>
                        {
                            OpenLink("https://discord.gg/cCQkWJ9j6W");
                        }),
                        new DialogButton("Close", true)
                    });
                    NewUpdateWindowHasBeenOpened = true;
                    ModAPI.SerialiseJSON(thisVersion, LastViewedVersionJsonPath);
                }
            }
        }

        public static void Main()
        {
            //https://colorscheme.ru/color-converter.html

            #region Birch: Tall
            ModAPI.Register(
            new Modification()
            {
                OriginalItem = TallTreeAsset,
                NameOverride = "Birch: Tall",
                DescriptionOverride = "Tallest birch.",
                NameToOrderByOverride = "VannilaE NatureAA",
                CategoryOverride = ModAPI.FindCategory("Misc."),
                ThumbnailOverride = ModAPI.LoadSprite("Thumbnails/Birch Tall.png"),
                AfterSpawn = (Instance) =>
                {
                    Instance.SetTrunkSprite(ModAPI.LoadSprite("Textures/Birch/Birch4.png", 1f), new Vector2[]
                    {
                        new Vector2(0.1118927f, 2.680643f),
                        new Vector2(0.07790647f, 3.907831f),
                        new Vector2(-0.0240144f, 4.075327f),
                        new Vector2(-0.1142748f, 3.099332f),
                        new Vector2(-0.1460961f, 2.474055f),
                        new Vector2(-0.07567406f, 0.8816471f),
                        new Vector2(-0.09013653f, -1.863775f),
                        new Vector2(-0.09965992f, -3.623142f),
                        new Vector2(-0.2142857f, -4.057143f),
                        new Vector2(0.2142857f, -4.057143f),
                        new Vector2(0.1479597f, -3.541393f),
                        new Vector2(0.1597346f, 2.06169f)
                    }); //Tree trunk texture
                    Instance.SetLeavesSprites(new (Sprite, Color)[] //Texture and color of leaves on branches
					{
                        (ModAPI.LoadSprite("Textures//leaves1.png", 1f), new Color(0.67f, 0.65f, 0.40f)),
                        (ModAPI.LoadSprite("Textures/leaves2.png", 1f), new Color(0.75f, 0.72f, 0.42f)),
                        (ModAPI.LoadSprite("Textures/leaves2.png", 1f), new Color(0.68f, 0.65f, 0.39f))
                    }, new Sprite[] //Falling leaves textures
					{
                        ModAPI.LoadSprite("Textures/Particles/Leaf1.png", 1f),
                        ModAPI.LoadSprite("Textures/Particles/Leaf2.png", 1f)
                    });

                    #region 0
                    Instance.EditLeaves(0, new Vector2[6]
                    {
						//new Vector2(0f, 0f),
						new Vector2(0.041f, 1.465f),
                        new Vector2(0.041f, 2.481f),
                        new Vector2(0.041f, 3.09f),
                        new Vector2(0.041f, 3.905f),
                        Vector2.zero,
                        Vector2.zero,
                    });
                    #endregion
                    #region 2 Branch !
                    Instance.EditBranch(2, 0, ModAPI.LoadSprite("Textures/Birch/Branch_6.png", 1f), new Vector2(0.3100004f, 6.886997f), 75.431f, new JointData(10000f, 0.7f, 5f));
                    Instance.EditLeaves(2, new Vector2[5]
                    {
                        new Vector2(0.708f, -0.002f),
                        new Vector2(-0.2366308f, 0.01598996f),
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero
                    });
                    #endregion
                    #region 3 Twin !2
                    Instance.EditBranch(3, 2, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(0.5100002f, 7.066998f), 51.014f, new JointData(10000f, 0.7f, 5f));
                    #endregion
                    #region 6 Branch !
                    Instance.EditBranch(6, 0, ModAPI.LoadSprite("Textures/Birch/Branch_8.png", 1f), new Vector2(-0.4300003f, 7.207001f), 125.82f, new JointData(10000f, 0.7f, 5f));
                    Instance.EditLeaves(6, new Vector2[1]
                    {
                        new Vector2(0.125f, 0.005f)
                    });
                    #endregion
                    #region 13 Branch !
                    Instance.EditBranch(13, 0, ModAPI.LoadSprite("Textures/Birch/Branch_1.png", 1f), new Vector2(0.54f, 5.717999f), 59.053f, new JointData(10000f, 0.7f, 5f));
                    Instance.EditLeaves(13, new Vector2[3]
                    {
                        new Vector2(0.74f, 0.065f),
                        new Vector2(-0.002391803f, 0.03121347f),
                        Vector2.zero
                    });
                    #endregion
                    #region 11 Twin !13
                    Instance.EditBranch(11, 13, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(0.6300001f, 6.267998f), 84.665f, new JointData(10000f, 0.7f, 5f));
                    #endregion
                    #region 12 Twin !13
                    Instance.EditBranch(12, 13, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(0.6949997f, 5.564999f), 32.175f, new JointData(10000f, 0.7f, 5f));
                    #endregion
                    #region 14 !
                    Instance.EditBranch(14, 0, ModAPI.LoadSprite("Textures/Birch/Branch_1.png", 1f), new Vector2(-0.4619999f, 5.997997f), 117.037f, new JointData(10000f, 0.7f, 5f));
                    Instance.EditLeaves(14, new Vector2[2]
                    {
                        new Vector2(0.646f, 0.076f),
                        new Vector2(-0.292982f, 0.04847714f)
                    });
                    #endregion
                    #region 15 !
                    Instance.EditBranch(15, 0, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(-0.2390005f, 3.629999f), 131.982f, new JointData(10000f, 0.7f, 5f));
                    Instance.EditLeaves(15, new Vector2[1]
                    {
                        new Vector2(0.243f, -0.005f)
                    });
                    #endregion
                    #region 16 !
                    Instance.EditBranch(16, 0, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(0.3089998f, 3.514999f), 63.621f, new JointData(10000f, 0.7f, 5f));
                    Instance.EditLeaves(16, new Vector2[1]
                    {
                        new Vector2(0.235f, -0.017f)
                    });
                    #endregion
                    #region 8 Twin !14
                    Instance.EditBranch(8, 14, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(-0.4160004f, 6.293999f), 90.843f, new JointData(10000f, 0.7f, 5f));
                    #endregion
                    #region 9 Twin !14
                    Instance.EditBranch(9, 14, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(-0.6940002f, 5.564999f), 160.772f, new JointData(10000f, 0.7f, 5f));
                    #endregion
                    #region DestroyBranch
                    Instance.DestroyBranch(1);
                    Instance.DestroyBranch(4);
                    Instance.DestroyBranch(5);
                    Instance.DestroyBranch(7);
                    Instance.DestroyBranch(10);
                    #endregion
                    #region DestroyAllLeaves
                    Instance.DestroyAllLeaves(8); //1 leaves
                    Instance.DestroyAllLeaves(9); //1 leaves
                    #endregion

                    Instance.UpdateSerialiseInstructions();

                    TryCreateInfoWindow();
                }
            });
            #endregion
            #region Birch: Medium
            ModAPI.Register(
            new Modification()
            {
                OriginalItem = TallTreeAsset,
                NameOverride = "Birch: Medium",
                DescriptionOverride = "Medium height birch",
                NameToOrderByOverride = "VannilaE NatureAA",
                CategoryOverride = ModAPI.FindCategory("Misc."),
                ThumbnailOverride = ModAPI.LoadSprite("Thumbnails/Birch Medium.png"),
                AfterSpawn = (Instance) =>
                {
                    Instance.SetTrunkSprite(ModAPI.LoadSprite("Textures/Birch/Birch5.png", 1f), new Vector2[]
                    {
                        new Vector2(0.02100154f, 3.381331f),
                        new Vector2(-0.09270287f, 2.094376f),
                        new Vector2(-0.08691172f, 0.3194917f),
                        new Vector2(-0.09731375f, -2.85513f),
                        new Vector2(-0.2142857f, -3.371428f),
                        new Vector2(0.2142857f, -3.371428f),
                        new Vector2(0.1687279f, -2.842947f),
                        new Vector2(0.1827496f, 0.6241601f),
                        new Vector2(0.1406386f, 3.087535f)
                    }); //Tree trunk texture
                    Instance.SetLeavesSprites(new (Sprite, Color)[] //Texture and color of leaves on branches
					{
                        (ModAPI.LoadSprite("Textures//leaves1.png", 1f), new Color(0.67f, 0.65f, 0.40f)),
                        (ModAPI.LoadSprite("Textures/leaves2.png", 1f), new Color(0.75f, 0.72f, 0.42f)),
                        (ModAPI.LoadSprite("Textures/leaves2.png", 1f), new Color(0.68f, 0.65f, 0.39f))
                    }, new Sprite[] //Falling leaves textures
					{
                        ModAPI.LoadSprite("Textures/Particles/Leaf1.png", 1f),
                        ModAPI.LoadSprite("Textures/Particles/Leaf2.png", 1f)
                    });

                    #region 0
                    Instance.EditLeaves(0, new Vector2[6]
                        {
							//new Vector2(0f, 0f),
							new Vector2(0.09600073f, 1.685998f),
                            new Vector2(0.09600073f, 2.295f),
                            new Vector2(0.03f, 3.11f),
                            Vector2.zero,
                            Vector2.zero,
                            Vector2.zero,
                        });
                    #endregion
                    #region 1
                    Instance.EditBranch(1, 0, ModAPI.LoadSprite("Textures/Birch/Branch_1.png", 1f), new Vector2(0.9809994f, 4.801001f), 23.832f, new JointData(10000f, 0.7f, 8f));
                    Instance.EditLeaves(1, new Vector2[7]
                    {
                        new Vector2(-0.336f, 0.005f),
                        new Vector2(0.608f, 0.06f),
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero
                    });
                    #endregion
                    #region 2
                    Instance.EditBranch(2, 1, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(1.028999f, 4.542001f), -11.17f, new JointData(10000f, 0.7f, 5f));
                    Instance.EditLeaves(2, new Vector2[5]
                    {
						//new Vector2(0f, 0f),
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero
                    });
                    #endregion
                    #region 3
                    Instance.EditBranch(3, 1, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(1.386999f, 5.391001f), 68.441f, new JointData(10000f, 0.7f, 5f));
                    #endregion
                    #region 6 !
                    Instance.EditBranch(6, 0, ModAPI.LoadSprite("Textures/Birch/Branch_8.png", 1f), new Vector2(0.3749994f, 6.068001f), 66.288f, new JointData(10000f, 0.7f, 5f));
                    Instance.EditLeaves(6, new Vector2[1]
                    {
                        new Vector2(0.068f, 0.013f)
                    });
                    #endregion
                    #region 7
                    Instance.EditBranch(7, 0, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(0.5439994f, 5.351001f), 45.309f, new JointData(10000f, 0.7f, 5f));
                    Instance.EditLeaves(7, new Vector2[5]
                    {
						//new Vector2(0f, 0f),
						new Vector2(0.402f, -0.025f),
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero
                    });
                    #endregion
                    #region 5 
                    Instance.EditBranch(5, 7, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(0.8679994f, 5.372001f), 15.704f, new JointData(10000f, 0.7f, 5f));
                    Instance.EditLeaves(5, new Vector2[7]
                    {
						//new Vector2(0f, 0f),
						Vector2.zero,
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero
                    });
                    #endregion
                    //left part				
                    #region 10
                    Instance.EditBranch(10, 0, ModAPI.LoadSprite("Textures/Birch/Branch_1.png", 1f), new Vector2(-0.8976231f, 4.743345f), 157.38f, new JointData(10000f, 0.7f, 8f));
                    Instance.EditLeaves(10, new Vector2[6]
                    {
						//new Vector2(-0.336f, 0.005f),
						new Vector2(-0.336f, 0.005f),
                        new Vector2(0.608f, 0.06f),
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero
                    });
                    #endregion
                    #region 8
                    Instance.EditBranch(8, 10, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(-0.7790006f, 4.388f), 185.839f, new JointData(10000f, 0.7f, 5f));
                    Instance.EditLeaves(8, new Vector2[1]
                    {
						//new Vector2(0f, 0f),
						Vector2.zero
                    });
                    #endregion
                    #region 9
                    Instance.EditBranch(9, 10, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(-1.079f, 5.03f), 127.411f, new JointData(10000f, 0.7f, 5f));
                    Instance.EditLeaves(9, new Vector2[1]
                    {
						//new Vector2(0f, 0f),
						Vector2.zero
                    });
                    #endregion
                    #region 13
                    Instance.EditBranch(13, 0, ModAPI.LoadSprite("Textures/Birch/Branch_8.png", 1f), new Vector2(-0.4470006f, 5.304001f), 138.051f, new JointData(10000f, 0.7f, 5f));
                    Instance.EditLeaves(13, new Vector2[3]
                    {
                        new Vector2(0.394f, 0.042f),
                        Vector2.zero,
                        Vector2.zero
                    });
                    #endregion
                    #region 11
                    Instance.EditBranch(11, 13, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(-0.7520006f, 5.317f), 166.027f, new JointData(10000f, 0.7f, 5f));
                    #endregion
                    #region 14
                    Instance.EditBranch(14, 0, ModAPI.LoadSprite("Textures/Birch/Branch_8.png", 1f), new Vector2(-0.3400006f, 6.025001f), 123.256f, new JointData(10000f, 0.7f, 5f));
                    Instance.EditLeaves(14, new Vector2[2]
                    {
                        new Vector2(0.068f, 0.013f),
                        Vector2.zero
                    });
                    #endregion
                    #region 12 
                    Instance.EditBranch(12, 14, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(-0.6000006f, 5.918f), 166.133f, new JointData(10000f, 0.7f, 5f));
                    #endregion
                    #region DestroyBranch
                    Instance.DestroyBranch(4);
                    Instance.DestroyBranch(15);
                    Instance.DestroyBranch(16);
                    #endregion

                    Instance.UpdateSerialiseInstructions();

                    TryCreateInfoWindow();
                }
            });
            #endregion
            #region Birch: Small
            ModAPI.Register(
            new Modification()
            {
                OriginalItem = TallTreeAsset,
                NameOverride = "Birch: Small",
                DescriptionOverride = "A small birch, but not the most.",
                NameToOrderByOverride = "VannilaE NatureAA",
                CategoryOverride = ModAPI.FindCategory("Misc."),
                ThumbnailOverride = ModAPI.LoadSprite("Thumbnails/Birch Small.png"),
                AfterSpawn = (Instance) =>
                {
                    Instance.SetTrunkSprite(ModAPI.LoadSprite("Textures/Birch/Birch2.png", 1f), new Vector2[]
                    {
                        new Vector2(-0.02968941f, 2.234963f),
                        new Vector2(-0.1304607f, 0.9791451f),
                        new Vector2(-0.1157579f, -1.177759f),
                        new Vector2(-0.1232719f, -1.932371f),
                        new Vector2(-0.1993237f, -2.226999f),
                        new Vector2(0.2142857f, -2.228571f),
                        new Vector2(0.1588936f, -1.694378f),
                        new Vector2(0.1496973f, -0.6532345f),
                        new Vector2(0.1746693f, 0.2613106f),
                        new Vector2(0.09488188f, 2.109218f)
                    });
                    Instance.SetLeavesSprites(new (Sprite, Color)[]
                    {
                        (ModAPI.LoadSprite("Textures//leaves1.png", 1f), new Color(0.67f, 0.65f, 0.40f)),
                        (ModAPI.LoadSprite("Textures/leaves2.png", 1f), new Color(0.75f, 0.72f, 0.42f)),
                        (ModAPI.LoadSprite("Textures/leaves2.png", 1f), new Color(0.68f, 0.65f, 0.39f))
                    }, new Sprite[]
                    {
                        ModAPI.LoadSprite("Textures/Particles/Leaf1.png", 1f),
                        ModAPI.LoadSprite("Textures/Particles/Leaf2.png", 1f)
                    });

                    //* Branches
                    Instance.EditLeaves(0, new Vector2[6]
                    {
                        new Vector2(0.007938385f, 2.019382f),
                        Vector2.zero,
                        new Vector2(-0.01806164f, 1.162382f),
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero,
                    });

                    Instance.EditBranch(1, 0, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(0.4060001f, 1.938f), 49.599f, new JointData(10000f, 0.7f, 4f));
                    Instance.EditLeaves(1, new Vector2[7]
                    {
                        new Vector2(0.2323013f, 0.02174996f),
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero
                    });

                    Instance.EditBranch(2, 0, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(-0.268f, 1.728f), 128.874f, new JointData(10000f, 0.7f, 4f));
                    Instance.EditLeaves(2, new Vector2[5]
                    {
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero,
                        new Vector2(0.2896401f, 0.02468526f),
                        Vector2.zero
                    });

                    Instance.EditBranch(3, 0, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(0.413f, 3.031f), 41.568f, new JointData(10000f, 0.7f, 4f));

                    Instance.EditBranch(4, 0, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(-0.2840004f, 2.871f), 141.112f, new JointData(10000f, 0.7f, 4f));

                    Instance.EditBranch(5, 0, ModAPI.LoadSprite("Textures/Birch/Branch_8.png", 1f), new Vector2(0.348f, 3.525f), 66.767f, new JointData(10000f, 0.7f, 4f));
                    Instance.DestroyAllLeaves(5);
                    Instance.EditBranch(6, 5, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(0.579f, 3.584f), 44.242f, new JointData(10000f, 0.7f, 4f));
                    Instance.EditLeaves(6, new Vector2[1]
                    {
                        new Vector2(0.0168944f, 0.005881664f),
                    });

                    Instance.EditBranch(7, 0, ModAPI.LoadSprite("Textures/Birch/Branch_8.png", 1f), new Vector2(-0.438f, 3.469f), 140.025f, new JointData(10000f, 0.7f, 4f));
                    Instance.EditLeaves(7, new Vector2[5]
                    {
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero,
                        new Vector2(0.3553457f, 0.02909324f)
                    });
                    Instance.EditBranch(8, 0, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(-0.214f, 3.914f), 118.244f, new JointData(10000f, 0.7f, 4f));
                    Instance.DestroyAllLeaves(8);

                    Instance.DestroyBranch(9);
                    Instance.DestroyBranch(10);
                    Instance.DestroyBranch(11);
                    Instance.DestroyBranch(12);
                    Instance.DestroyBranch(13);
                    Instance.DestroyBranch(14);
                    Instance.DestroyBranch(15);
                    Instance.DestroyBranch(16);

                    //* Twigs
                    //Instance.EditBranch(3, ModAPI.LoadSprite("Textures/Big_Birch/Branch_9.png", 1f), new Vector2(1.3152f, 4.2494f), 17f, new JointData(5000f));
                    //Instance.EditBranch(4, ModAPI.LoadSprite("Textures/Big_Birch/Branch_9.png", 1f), new Vector2(1.0895f, 4.6681f), 82f, new JointData(5000f));

                    //Instance.EditBranch(6, 2, ModAPI.LoadSprite("Textures/Big_Birch/Branch_9.png", 1f), new Vector2(0.7835f, 3.3647f), 342f, new JointData(5000f));

                    Instance.UpdateSerialiseInstructions();

                    TryCreateInfoWindow();
                }
            });
            #endregion
            #region Birch: Thin
            ModAPI.Register(
            new Modification()
            {
                OriginalItem = TallTreeAsset,
                NameOverride = "Birch: Thin",
                DescriptionOverride = "Lowest birch. This birch also has a thin trunk",
                NameToOrderByOverride = "VannilaE NatureAA",
                CategoryOverride = ModAPI.FindCategory("Misc."),
                ThumbnailOverride = ModAPI.LoadSprite("Thumbnails/Birch Thin.png"),
                AfterSpawn = (Instance) =>
                {
                    Instance.SetTrunkSprite(ModAPI.LoadSprite("Textures/Birch/Birch3.png", 1f), new Vector2[]
                    {
                        new Vector2(0.05098724f, 1.012445f),
                        new Vector2(-0.009059504f, 1.066699f),
                        new Vector2(-0.05479622f, 0.8565941f),
                        new Vector2(-0.08012867f, -0.7297497f),
                        new Vector2(-0.1714286f, -1.057143f),
                        new Vector2(0.1714286f, -1.057143f),
                        new Vector2(0.1142817f, -0.8916359f),
                        new Vector2(0.05014038f, 0.2653942f)
                    }); //Tree trunk texture
                    Instance.SetLeavesSprites(new (Sprite, Color)[] //Texture and color of leaves on branches
					{
                        (ModAPI.LoadSprite("Textures//leaves1.png", 1f), new Color(0.67f, 0.65f, 0.40f)),
                        (ModAPI.LoadSprite("Textures/leaves2.png", 1f), new Color(0.75f, 0.72f, 0.42f)),
                        (ModAPI.LoadSprite("Textures/leaves2.png", 1f), new Color(0.68f, 0.65f, 0.39f))
                    }, new Sprite[] //Falling leaves textures
					{
                        ModAPI.LoadSprite("Textures/Particles/Leaf1.png", 1f),
                        ModAPI.LoadSprite("Textures/Particles/Leaf2.png", 1f)
                    });
                    #region 0
                    Instance.EditLeaves(0, new Vector2[6]
                    {
						//new Vector2(0f, 0f),
						Vector2.zero,
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero,
                    });
                    #endregion
                    #region 1
                    Instance.EditBranch(1, 0, ModAPI.LoadSprite("Textures/Birch/Branch_8.png", 1f), new Vector2(-0.165f, 2.620001f), 105.788f, new JointData(10000f, 0.7f, 5f));
                    Instance.EditLeaves(1, new Vector2[7]
                    {
                        new Vector2(0.4462954f, -0.05344695f),
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero
                    });
                    #endregion
                    #region 2
                    Instance.EditBranch(2, 1, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(-0.2980003f, 3.507999f), 89.823f, new JointData(10000f, 0.7f, 5f));
                    Instance.EditLeaves(2, new Vector2[5]
                    {
                        new Vector2(0.2349656f, 0.01172456f),
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero
                    });
                    #endregion
                    #region 3
                    Instance.EditBranch(3, 1, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(-0.5835762f, 2.949049f), 160.772f, new JointData(10000f, 0.7f, 5f));
                    #endregion
                    #region 10
                    Instance.EditBranch(10, 1, ModAPI.LoadSprite("Textures/Birch/Branch_8.png", 1f), new Vector2(0.08699989f, 3.052f), 72.26f, new JointData(20000f, 0.7f, 12f));
                    Instance.EditLeaves(10, new Vector2[6]
                    {
						//new Vector2(0f, 0f),
						new Vector2(0.368f, 0.005f),
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero
                    });
                    #endregion
                    #region 5
                    Instance.EditBranch(5, 10, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(0.3809996f, 3.075001f), 39.119f, new JointData(10000f, 0.7f, 5f));
                    Instance.EditLeaves(5, new Vector2[7]
                    {
                        new Vector2(0.3087887f, -0.01653045f),
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero
                    });
                    #endregion
                    #region 6 !
                    Instance.EditBranch(6, 0, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(0.1859999f, 2.132f), 66.66f, new JointData(10000f, 0.7f, 5f));
                    Instance.EditLeaves(6, new Vector2[1]
                    {
                        new Vector2(0.3189632f, -0.007220283f)
                    });
                    #endregion
                    #region DestroyBranch
                    Instance.DestroyBranch(4);
                    Instance.DestroyBranch(7);
                    Instance.DestroyBranch(8);
                    Instance.DestroyBranch(9);
                    Instance.DestroyBranch(11);
                    Instance.DestroyBranch(12);
                    Instance.DestroyBranch(13);
                    Instance.DestroyBranch(14);
                    Instance.DestroyBranch(15);
                    Instance.DestroyBranch(16);
                    #endregion

                    Instance.UpdateSerialiseInstructions();

                    TryCreateInfoWindow();
                }
            });
            #endregion

            #region Pine: Tall
            ModAPI.Register(
            new Modification()
            {
                OriginalItem = TallTreeAsset,
                NameOverride = "Pine: Tall",
                DescriptionOverride = "A tall pine tree. Pretty wide trunk and very many branches.",
                NameToOrderByOverride = "VannilaE NatureAA",
                CategoryOverride = ModAPI.FindCategory("Misc."),
                ThumbnailOverride = ModAPI.LoadSprite("Thumbnails/Pine Tall.png"),
                AfterSpawn = (Instance) =>
                {
                    #region Trunk
                    Instance.SetTrunkSprite(ModAPI.LoadSprite("Textures/Pine/Pine.png", 1f), new Vector2[]
                    {
                        new Vector2(0.2735901f, 2.301308f),
                        new Vector2(0.2406778f, 2.76614f),
                        new Vector2(0.2530861f, 4.787163f),
                        new Vector2(0.2155914f, 5.581211f),
                        new Vector2(0.2191105f, 6.369305f),
                        new Vector2(0.04608554f, 6.997869f),
                        new Vector2(-0.06359863f, 6.337227f),
                        new Vector2(-0.09588242f, 3.512947f),
                        new Vector2(-0.3117714f, -6.002634f),
                        new Vector2(-0.5f, -6.985714f),
                        new Vector2(0.5f, -6.985714f),
                        new Vector2(0.3546658f, -6.030799f)
                    }); //Tree trunk texture
                    Instance.SetLeavesSprites(new (Sprite, Color)[] //Texture and color of leaves on branches
					{
                        (ModAPI.LoadSprite("Textures/leaves1.png", 1f), new Color(0.51f, 0.56f, 0.30f)),
                        (ModAPI.LoadSprite("Textures/leaves1.png", 1f), new Color(0.56f, 0.62f, 0.34f)),
                        (ModAPI.LoadSprite("Textures/leaves2.png", 1f), new Color(0.55f, 0.60f, 0.33f))
                    }, new Sprite[] //Falling leaves textures
					{
                        ModAPI.LoadSprite("Textures/Particles/Leaf1.png", 1f),
                        ModAPI.LoadSprite("Textures/Particles/Leaf2.png", 1f)
                    });
                    Instance.EditLeaves(0, new Vector2[6]
                    {
						//new Vector2(0f, 0f),
						new Vector2(0.063f, 4.649f),
                        new Vector2(0.063f, 5.472f),
                        new Vector2(0.063f, 6.453f),
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero,
                    });
                    #endregion
                    #region Branch
                    //Line 1
                    Instance.EditBranch(6, 0, ModAPI.LoadSprite("Textures/Pine/Branch_5.png", 1f), new Vector2(0.614f, 6.18927f), 39.398f, new JointData(10000f, 0.7f, 3.5f)); // 1
                    Instance.EditLeaves(6, new Vector2[1]
                        {
                        new Vector2(0.408f, -0.011f),
                        });
                    Instance.EditBranch(8, 0, ModAPI.LoadSprite("Textures/Pine/Branch_5.png", 1f), new Vector2(-0.5570002f, 6.237999f), 139.173f, new JointData(10000f, 0.7f, 3.5f)); // 1
                    Instance.EditLeaves(8, new Vector2[1]
                        {
                        new Vector2(0.421f, 0.017f),
                        });
                    //Line 2
                    Instance.EditBranch(14, 0, ModAPI.LoadSprite("Textures/Pine/Branch_2.png", 1f), new Vector2(1.397f, 8.574999f), 25.243f, new JointData(10000f, 0.7f, 3.5f)); // 2
                    Instance.EditLeaves(14, new Vector2[2]
                        {
                        new Vector2(-0.42f, -0.091f),
                        new Vector2(0.8f, -0.03f),
                        });
                    Instance.EditBranch(13, 0, ModAPI.LoadSprite("Textures/Pine/Branch_2.png", 1f), new Vector2(-1.304f, 8.560999f), 156.859f, new JointData(10000f, 0.7f, 3.5f)); // 3
                    Instance.EditLeaves(13, new Vector2[3]
                        {
                        new Vector2(-0.464f, 0.049f),
                        new Vector2(0.694f, 0.071f),
                        Vector2.zero,
                        });
                    Instance.EditBranch(2, 0, ModAPI.LoadSprite("Textures/Pine/Branch_2.png", 1f), new Vector2(1.094f, 9.224998f), 31.141f, new JointData(10000f, 0.7f, 3.5f)); // 5
                    Instance.EditLeaves(2, new Vector2[5]
                        {
                        new Vector2(-0.239f, 0.036f),
                        new Vector2(0.733f, -0.009f),
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero
                        });
                    Instance.EditBranch(7, 0, ModAPI.LoadSprite("Textures/Pine/Branch_2.png", 1f), new Vector2(-0.964f, 9.213999f), 151.331f, new JointData(10000f, 0.7f, 3.5f)); // 5
                    Instance.EditLeaves(7, new Vector2[5]
                        {
                        new Vector2(-0.182f, 0.05f),
                        new Vector2(0.77f, 0.063f),
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero
                        });
                    //Line3
                    Instance.EditBranch(3, 0, ModAPI.LoadSprite("Textures/Pine/Branch_5.png", 1f), new Vector2(0.666f, 10.368f), 33.469f, new JointData(10000f, 0.7f, 3.5f)); // 0
                    Instance.EditBranch(4, 0, ModAPI.LoadSprite("Textures/Pine/Branch_5.png", 1f), new Vector2(-0.49f, 10.271f), 131.827f, new JointData(10000f, 0.7f, 3.5f)); // 0
                                                                                                                                                                               //Line4
                    Instance.EditBranch(10, 0, ModAPI.LoadSprite("Textures/Pine/Branch_3.png", 1f), new Vector2(1.31f, 11.331f), 31.071f, new JointData(10000f, 0.7f, 3.5f)); // 6
                    Instance.EditLeaves(10, new Vector2[6]
                        {
                        new Vector2(-0.07099982f, 0.005000814f),
                        new Vector2(0.9130009f, 0.02100132f),
                        new Vector2(-0.9219995f, -0.0209993f),
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero
                        });
                    Instance.EditBranch(1, 0, ModAPI.LoadSprite("Textures/Pine/Branch_3.png", 1f), new Vector2(-1.14f, 11.371f), 149.026f, new JointData(10000f, 0.7f, 3.5f)); // 7
                    Instance.EditLeaves(1, new Vector2[6]
                        {
                        new Vector2(-0.057f, 0.107f),
                        new Vector2(0.897f, 0.002f),
                        new Vector2(-0.936f, 0.06f),
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero
                        });

                    Instance.EditBranch(9, 10, ModAPI.LoadSprite("Textures/Pine/Branch_4.png", 1f), new Vector2(1.795f, 10.98f), 2.78f, new JointData(10000f, 0.7f, 3.5f)); // 1
                    Instance.EditLeaves(9, new Vector2[1]
                        {
                        new Vector2(0.363f, 0.035f),
                        });
                    Instance.EditBranch(15, 1, ModAPI.LoadSprite("Textures/Pine/Branch_4.png", 1f), new Vector2(-1.577f, 11.077f), 174.072f, new JointData(10000f, 0.7f, 3.5f)); // 1
                    Instance.EditLeaves(15, new Vector2[1]
                        {
                        new Vector2(0.487f, 0.003f),
                        });
                    //Line 5
                    Instance.EditBranch(5, 0, ModAPI.LoadSprite("Textures/Pine/Branch_4.png", 1f), new Vector2(0.94f, 12.141f), 40.38f, new JointData(10000f, 0.7f, 3.5f)); // 7
                    Instance.EditLeaves(5, new Vector2[7]
                        {
                        new Vector2(-0.433f, 0.04f),
                        new Vector2(0.546f, -0.003f),
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero
                        });

                    Instance.EditBranch(16, 0, ModAPI.LoadSprite("Textures/Pine/Branch_4.png", 1f), new Vector2(-0.7609997f, 12.168f), 140f, new JointData(10000f, 0.7f, 3.5f)); // 1
                    Instance.EditLeaves(16, new Vector2[1]
                        {
                        new Vector2(-0.388f, 0.024f),
                            //new Vector2(0.532f, 0.043f),
                        });
                    Instance.AddLeaf(16, new Vector2(0.532f, 0.043f), ModAPI.LoadSprite("Textures/leaves2.png", 1f), new Color(0.56f, 0.62f, 0.34f));
                    //Line 6
                    Instance.EditBranch(11, 0, ModAPI.LoadSprite("Textures/Pine/Branch_5.png", 1f), new Vector2(0.625f, 12.97f), 40.38f, new JointData(10000f, 0.7f, 3.5f)); // 0
                    Instance.AddLeaf(11, new Vector2(0.074f, 0.012f), ModAPI.LoadSprite("Textures/leaves2.png", 1f), new Color(0.55f, 0.60f, 0.33f));

                    Instance.EditBranch(12, 0, ModAPI.LoadSprite("Textures/Pine/Branch_5.png", 1f), new Vector2(-0.519f, 12.95f), 140f, new JointData(10000f, 0.7f, 3.5f)); // 0
                    Instance.AddLeaf(12, new Vector2(-0.022f, 0.04f), ModAPI.LoadSprite("Textures/leaves2.png", 1f), new Color(0.56f, 0.62f, 0.34f));
                    #endregion
                    Instance.UpdateSerialiseInstructions();
                    TryCreateInfoWindow();
                }
            });
            #endregion
            #region Pine: Tall 2
            ModAPI.Register(
            new Modification()
            {
                OriginalItem = TallTreeAsset,
                NameOverride = "Pine: Tall 2",
                DescriptionOverride = "Also a pine, also tall, but with fewer branches",
                NameToOrderByOverride = "VannilaE NatureAA",
                CategoryOverride = ModAPI.FindCategory("Misc."),
                ThumbnailOverride = ModAPI.LoadSprite("Thumbnails/Pine Tall 2.png"),
                AfterSpawn = (Instance) =>
                {
                    #region Trunk
                    Instance.SetTrunkSprite(ModAPI.LoadSprite("Textures/Pine/Pine.png", 1f), new Vector2[]
                    {
                        new Vector2(0.2735901f, 2.301308f),
                        new Vector2(0.2406778f, 2.76614f),
                        new Vector2(0.2530861f, 4.787163f),
                        new Vector2(0.2155914f, 5.581211f),
                        new Vector2(0.2191105f, 6.369305f),
                        new Vector2(0.04608554f, 6.997869f),
                        new Vector2(-0.06359863f, 6.337227f),
                        new Vector2(-0.09588242f, 3.512947f),
                        new Vector2(-0.3117714f, -6.002634f),
                        new Vector2(-0.5f, -6.985714f),
                        new Vector2(0.5f, -6.985714f),
                        new Vector2(0.3546658f, -6.030799f)
                    }); //Tree trunk texture
                    Instance.SetLeavesSprites(new (Sprite, Color)[] //Texture and color of leaves on branches
					{
                        (ModAPI.LoadSprite("Textures/leaves1.png", 1f), new Color(0.51f, 0.56f, 0.30f)),
                        (ModAPI.LoadSprite("Textures/leaves1.png", 1f), new Color(0.56f, 0.62f, 0.34f)),
                        (ModAPI.LoadSprite("Textures/leaves2.png", 1f), new Color(0.55f, 0.60f, 0.33f))
                    }, new Sprite[] //Falling leaves textures
					{
                        ModAPI.LoadSprite("Textures/Particles/Leaf1.png", 1f),
                        ModAPI.LoadSprite("Textures/Particles/Leaf2.png", 1f)
                    });
                    Instance.EditLeaves(0, new Vector2[6]
                    {
						//new Vector2(0f, 0f),
						new Vector2(0.063f, 4.785f),
                        new Vector2(0.063f, 5.767f),
                        new Vector2(0.063f, 6.718f),
                        Vector2.zero,
                        Vector2.zero,
                        Vector2.zero,
                    });
                    #endregion

                    #region Branch
                    #region Right side
                    Instance.EditBranch(3, 0, ModAPI.LoadSprite("Textures/Pine/Branch_3.png", 1f), new Vector2(1.633f, 10.515f), 15.433f, new JointData(7000f, 0.7f, 4f)); // 0
                    Instance.AddLeaf(3, new Vector2(-0.07099982f, 0.005000814f), ModAPI.LoadSprite("Textures/leaves1.png", 1f), new Color(0.56f, 0.62f, 0.34f));
                    Instance.AddLeaf(3, new Vector2(0.9130009f, 0.02100132f), ModAPI.LoadSprite("Textures/leaves2.png", 1f), new Color(0.56f, 0.62f, 0.34f));
                    Instance.AddLeaf(3, new Vector2(-0.9219995f, -0.0209993f), ModAPI.LoadSprite("Textures/leaves2.png", 1f), new Color(0.56f, 0.62f, 0.34f));
                    //Instance.AddObject(3, ModAPI.LoadSprite("Textures/46564.png", 1f), new Vector2(0.074f, 0.012f), 0f, new Vector2(0.04f, 0.32f), new JointData(500f, 0.1f, 0.3f), "Soft"); //! Object

                    Instance.EditBranch(4, 0, ModAPI.LoadSprite("Textures/Pine/Branch_3.png", 1f), new Vector2(1.487f, 11.298f), 23.728f, new JointData(7000f, 0.7f, 4f)); // 0
                    Instance.AddLeaf(4, new Vector2(-0.07099982f, 0.005000814f), ModAPI.LoadSprite("Textures/leaves2.png", 1f), new Color(0.56f, 0.62f, 0.34f));
                    Instance.AddLeaf(4, new Vector2(0.9130009f, 0.02100132f), ModAPI.LoadSprite("Textures/leaves1.png", 1f), new Color(0.56f, 0.62f, 0.34f));
                    Instance.AddLeaf(4, new Vector2(-0.9219995f, -0.0209993f), ModAPI.LoadSprite("Textures/leaves1.png", 1f), new Color(0.56f, 0.62f, 0.34f));

                    Instance.EditBranch(11, 0, ModAPI.LoadSprite("Textures/Pine/Branch_4.png", 1f), new Vector2(1.085033f, 11.87584f), 30.219f, new JointData(7000f, 0.7f, 4f)); // 0
                    Instance.AddLeaf(11, new Vector2(-0.205f, 0.035f), ModAPI.LoadSprite("Textures/leaves1.png", 1f), new Color(0.56f, 0.62f, 0.34f));
                    Instance.AddLeaf(11, new Vector2(0.738f, 0.021f), ModAPI.LoadSprite("Textures/leaves2.png", 1f), new Color(0.56f, 0.62f, 0.34f));

                    Instance.EditBranch(12, 0, ModAPI.LoadSprite("Textures/Pine/Branch_4.png", 1f), new Vector2(0.857f, 12.485f), 42.285f, new JointData(7000f, 0.7f, 4f)); // 0
                    Instance.AddLeaf(12, new Vector2(-0.085f, 0.002f), ModAPI.LoadSprite("Textures/leaves2.png", 1f), new Color(0.56f, 0.62f, 0.34f));
                    Instance.AddLeaf(12, new Vector2(0.738f, 0.021f), ModAPI.LoadSprite("Textures/leaves1.png", 1f), new Color(0.56f, 0.62f, 0.34f));

                    Instance.EditBranch(15, 0, ModAPI.LoadSprite("Textures/Pine/Branch_5.png", 1f), new Vector2(0.611f, 13.29f), 40.38f, new JointData(7000f, 0.7f, 4f)); // 1
                    Instance.EditLeaves(15, new Vector2[1]
                    {
                        new Vector2(0.074f, 0.012f)
                    });
                    #endregion
                    #region Left side
                    Instance.EditBranch(2, 0, ModAPI.LoadSprite("Textures/Pine/Branch_3.png", 1f), new Vector2(-1.411f, 10.534f), 163.573f, new JointData(7000f, 0.7f, 4f)); // 5
                    Instance.EditLeaves(2, new Vector2[5]
                    {
                        new Vector2(-0.07099982f, 0.005000814f),
                        new Vector2(0.9130009f, 0.02100132f),
                        new Vector2(-0.9219995f, -0.0209993f),
                        Vector2.zero,
                        Vector2.zero
                    });

                    Instance.EditBranch(7, 0, ModAPI.LoadSprite("Textures/Pine/Branch_3.png", 1f), new Vector2(-1.244f, 11.32f), 154.579f, new JointData(7000f, 0.7f, 4f)); // 5
                    Instance.EditLeaves(7, new Vector2[5]
                    {
                        new Vector2(-0.07099982f, 0.005000814f),
                        new Vector2(0.9130009f, 0.02100132f),
                        new Vector2(-0.9219995f, -0.0209993f),
                        Vector2.zero,
                        Vector2.zero
                    });

                    Instance.EditBranch(13, 0, ModAPI.LoadSprite("Textures/Pine/Branch_4.png", 1f), new Vector2(-0.869f, 11.928f), 148.62f, new JointData(7000f, 0.7f, 4f)); // 3
                    Instance.EditLeaves(13, new Vector2[3]
                    {
                        new Vector2(-0.205f, 0.035f),
                        new Vector2(0.738f, 0.021f),
                        Vector2.zero
                    });

                    Instance.EditBranch(14, 0, ModAPI.LoadSprite("Textures/Pine/Branch_4.png", 1f), new Vector2(-0.529f, 12.469f), 135.228f, new JointData(7000f, 0.7f, 4f)); // 2
                    Instance.EditLeaves(14, new Vector2[2]
                    {
                        new Vector2(-0.205f, 0.035f),
                        new Vector2(0.738f, 0.021f)
                    });

                    Instance.EditBranch(16, 0, ModAPI.LoadSprite("Textures/Pine/Branch_5.png", 1f), new Vector2(-0.452f, 13.306f), 133.805f, new JointData(7000f, 0.7f, 4f)); // 1 

                    Instance.AddLeaf(16, new Vector2(0.074f, 0.012f), ModAPI.LoadSprite("Textures/leaves1.png", 1f), new Color(0.56f, 0.62f, 0.34f));
                    #endregion
                    #endregion

                    Instance.DestroyBranch(1);
                    Instance.DestroyBranch(5);
                    Instance.DestroyBranch(6);
                    Instance.DestroyBranch(8);
                    Instance.DestroyBranch(9);
                    Instance.DestroyBranch(10);

                    Instance.UpdateSerialiseInstructions();
                    TryCreateInfoWindow();
                }
            });
            #endregion
            #region Example Tree
            #endregion
        }
    }
    public class ObjectSerialisationHelper : MonoBehaviour
    {
        private void OnBeforeSerialise()
        {
            if (Objects == null || Objects.Count == 0)
            {
                return;
            }
            foreach (GameObject gameObject in Objects)
            {
                gameObject.SendMessage("OnBeforeSerialise", SendMessageOptions.DontRequireReceiver);
            }
            SerialisedObjects = Array.ConvertAll(Objects.ToArray(), obj => new GameObjectInfo(obj));
        }
        private void OnAfterDeserialise(List<GameObject> gameObjects)
        {
            if (SerialisedObjects == null || SerialisedObjects.Length == 0)
            {
                return;
            }
            SerialisableIdentity serialisableIdentity = null;
            IEnumerable<SerialisableIdentity> serialisableIdentities = from gameObject in gameObjects
                                                                       where gameObject.TryGetComponent(out serialisableIdentity)
                                                                       select serialisableIdentity;
            foreach (GameObjectInfo objectInfo in SerialisedObjects)
            {
                Transform transform = this.transform.Find(objectInfo.Name);
                if (transform == null)
                {
                    continue;
                }
                GameObject gameObject = transform.gameObject;
                objectInfo.WriteTo(gameObject, serialisableIdentities);
                Objects.Add(gameObject);
            }
        }

        [SkipSerialisation]
        public List<GameObject> Objects = new List<GameObject>();
        public GameObjectInfo[] SerialisedObjects;
    }
    [Serializable]
    public struct GameObjectInfo
    {
        public GameObjectInfo(GameObject gameObject)
        {
            Name = Utils.GetHierachyPath(gameObject.transform);
            Transform = new TransformPrototype(gameObject.transform.root.InverseTransformPoint(gameObject.transform.position), gameObject.transform.eulerAngles.z - gameObject.transform.root.eulerAngles.z, gameObject.transform.localScale);
            List<MonoBehaviourPrototype> list = new List<MonoBehaviourPrototype>();
            foreach (MonoBehaviour monoBehaviour in gameObject.GetComponents<MonoBehaviour>().Where((m) => IsSerialisableMonoBehaviour(m)))
            {
                list.Add(new MonoBehaviourPrototype(monoBehaviour));
            }
            Data = list.ToArray();
        }
        public void WriteTo(GameObject gameObject, IEnumerable<SerialisableIdentity> serialisableIdentities)
        {
            if (!gameObject || Utils.GetHierachyPath(gameObject.transform) != Name)
            {
                return;
            }
            gameObject.transform.position = gameObject.transform.root.TransformPoint(Transform.RelativePosition);
            gameObject.transform.eulerAngles = new Vector3(0f, 0f, Transform.RelativeRotation + gameObject.transform.parent.eulerAngles.z);
            gameObject.transform.localScale = Transform.LocalScale;
            List<MonoBehaviour> list = gameObject.GetComponents<MonoBehaviour>().ToList();
            foreach (MonoBehaviourPrototype prototype in Data)
            {
                MonoBehaviour monoBehaviour = list.FirstOrDefault((m) => m.GetType() == prototype.Type);
                if (monoBehaviour == null)
                {
                    monoBehaviour = gameObject.AddComponent(prototype.Type) as MonoBehaviour;
                }
                prototype.InjectIntoMonoBehaviour(monoBehaviour);
                prototype.LinkReferencesToMonoBehaviour(monoBehaviour, serialisableIdentities);
                list.Remove(monoBehaviour);
            }
        }
        private static bool IsSerialisableMonoBehaviour(MonoBehaviour monoBehaviour)
        {
            return monoBehaviour.GetType().GetCustomAttribute<SkipSerialisationAttribute>() == null && !(monoBehaviour is DeregisterBehaviour) && !(monoBehaviour is TexturePackApplier) && !(monoBehaviour is DecalControllerBehaviour) && !(monoBehaviour is FrozenInIceBehaviour) && !(monoBehaviour is SerialiseInstructions) && !(monoBehaviour is AudioSourceTimeScaleBehaviour) && !(monoBehaviour is Optout) && !(monoBehaviour is SerpentineBeltBehaviour);
        }

        public string Name;
        public TransformPrototype Transform;
        public MonoBehaviourPrototype[] Data;
    }

    public sealed class ChangeParentOnJointBreak : MonoBehaviour, Messages.IOnBeforeSerialise, Messages.IOnAfterDeserialise
    {
        [SkipSerialisation]
        private JointSerialisationHelper SerialisationHelper;
        [SkipSerialisation]
        private Transform StartParent;
        [SkipSerialisation]
        private Transform Parent;

        public void Set(JointSerialisationHelper serialisationHelper, Transform parent)
        {
            SerialisationHelper = serialisationHelper;
            StartParent = transform.parent;
            Parent = parent;
        }
        private void OnJointBreak2D(Joint2D joint)
        {
            if (SerialisationHelper.Joint != joint)
            {
                return;
            }
            transform.SetParent(Parent);
        }
        public void OnBeforeSerialise()
        {
            transform.SetParent(StartParent);
        }
        public void OnAfterDeserialise(List<GameObject> _)
        {
            if (SerialisationHelper.Broken)
            {
                transform.SetParent(Parent);
            }
        }
    }
}
// Originally uploaded by 'Int team'. Do not reupload without their explicit permission.
