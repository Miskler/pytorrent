//https://colorscheme.ru/color-converter.html

//EditBranch
Instance.EditBranch(1, 0, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(00000000f, 00000000f), 00000000f, new JointData(10000f, 0.7f, 5f)); // 7
Instance.EditBranch(2, 0, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(00000000f, 00000000f), 00000000f, new JointData(10000f, 0.7f, 5f)); // 5
Instance.EditBranch(3, 0, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(00000000f, 00000000f), 00000000f, new JointData(10000f, 0.7f, 5f)); // 0
Instance.EditBranch(4, 0, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(00000000f, 00000000f), 00000000f, new JointData(10000f, 0.7f, 5f)); // 0
Instance.EditBranch(5, 0, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(00000000f, 00000000f), 00000000f, new JointData(10000f, 0.7f, 5f)); // 7
Instance.EditBranch(6, 0, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(00000000f, 00000000f), 00000000f, new JointData(10000f, 0.7f, 5f)); // 1
Instance.EditBranch(7, 0, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(00000000f, 00000000f), 00000000f, new JointData(10000f, 0.7f, 5f)); // 5
Instance.EditBranch(8, 0, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(00000000f, 00000000f), 00000000f, new JointData(10000f, 0.7f, 5f)); // 1
Instance.EditBranch(9, 0, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(00000000f, 00000000f), 00000000f, new JointData(10000f, 0.7f, 5f)); // 1
Instance.EditBranch(10, 0, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(00000000f, 00000000f), 00000000f, new JointData(10000f, 0.7f, 5f)); // 6
Instance.EditBranch(11, 0, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(00000000f, 00000000f), 00000000f, new JointData(10000f, 0.7f, 5f)); // 0
Instance.EditBranch(12, 0, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(00000000f, 00000000f), 00000000f, new JointData(10000f, 0.7f, 5f)); // 0
Instance.EditBranch(13, 0, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(00000000f, 00000000f), 00000000f, new JointData(10000f, 0.7f, 5f)); // 3
Instance.EditBranch(14, 0, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(00000000f, 00000000f), 00000000f, new JointData(10000f, 0.7f, 5f)); // 2
Instance.EditBranch(15, 0, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(00000000f, 00000000f), 00000000f, new JointData(10000f, 0.7f, 5f)); // 1
Instance.EditBranch(16, 0, ModAPI.LoadSprite("Textures/Birch/Branch_9.png", 1f), new Vector2(00000000f, 00000000f), 00000000f, new JointData(10000f, 0.7f, 5f)); // 1

//EditLeaves
                    Instance.EditLeaves(0, new Vector2[2]
                    {
                        new Vector2(0000000f, 0000000f),
                        Vector2.zero,
                    });

                    Instance.AddLeaf(16, new Vector2(000000000f, 000000000f), ModAPI.LoadSprite("Textures/leaves2.png", 1f), new Color(0.56f, 0.62f, 0.34f));
    //Leaves on each branch:
    //0: 6
    //1: 7
    //2: 5
    //3: 0
    //4: 0
    //5: 7
    //6: 1
    //7: 5
    //8: 1
    //9: 1
    //10: 6
    //11: 0
    //12: 0
    //13: 3
    //14: 2
    //15: 1
    //16: 1

    //Leaves on each branch by number:
    //3: 0
    //4: 0
    //11: 0
    //12: 0
    //6: 1
    //8: 1
    //9: 1
    //15: 1
    //16: 1
    //14: 2
    //13: 3
    //2: 5
    //7: 5
    //10: 6 
    //1: 7   
    //5: 7
// Originally uploaded by 'Int team'. Do not reupload without their explicit permission.
